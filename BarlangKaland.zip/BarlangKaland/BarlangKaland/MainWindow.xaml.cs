﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BarlangKaland
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int LocalizationNo;
        public MainWindow(string nyelv)
        {
            LocalizationNo = Convert.ToInt32(nyelv);
            InitializeComponent();
            richstorybox.IsReadOnly = true;
            if (LocalizationNo == 1)
            {
                this.Title = "Barlang Kaland";
                item.Text = "Üres";
                useitem.Content = "Tárgy";
                healthtext.Content = "Életerő";
                richstorybox.AppendText("Üdvözöllek! Itt állsz a barlang bejáratánál. A helyzetet itt fogod látni szövegként, a cselekmények, amiket csinálhatsz, sorrendben lesznek itt, azaz az első az 1-es, második a 2-es, harmadik a 3-as gomb. Nem feltétlenül lesz mindig többféle lehetőség. A tárgy gombbal használod vagy megnézed a nálad lévő adott tárgyat. Az életerő az nem gomb. Ha a szövegdoboz betelt, görgess az egérrel! Találd meg a kincset, szerezz különleges tárgyakat, és lehetőleg a legtöbb életerővel juss ki!\rMerre szeretnél menni? Be a barlangba, a barlang melletti kocsmába vagy a vízeséshez?");
            }
            else if (LocalizationNo == 2)
            {
                this.Title = "Cave adventure";
                item.Text = "Empty";
                useitem.Content = "Item";
                healthtext.Content = "Health";
                richstorybox.AppendText("Welcome! You are currently standing at the entrance of the cave. You will see a description of the place you are currently in and what actions you can take written here, in order from 1 to 3. The actions will be 1, 2 and 3 in the listed order. There are rooms with two or less options though. You can use or inspect your item with the item button. The health text isn't a button. If you see that this text box has filled up, scroll down to read the new text! Find the treasure, collect special items and leave with the most health!\rWhere would you like to go? Straight into the cave, to the pub next to the cave or to the waterfall?");
            }
        }
        int roomno = 1;
        int itemname = 0;
        int health = 3;
        int win = 0;
        int death = 0;
        int csonti = 0;
        int uresnezes = 0;
        int lampanezes = 0;
        int kardnezes = 0;
        int kincsnezes = 0;
        int pancelnezes = 0;
        int voltkardod = 0;
        int voltpancelod = 0;
        private void option1_Click(object sender, RoutedEventArgs e)
        {
            if (health != 0 && win !=1)
            {
                if (roomno == 1)
                {
                    roomno = 2;
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rBeléptél a barlangba. Látsz egy szakadékot, egy sötét, nyálkás barlangrészt és egy járatot. Merre mész?");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rYou enter the cave. You see a chasm, a dark, slimy part of the cave and a passage. Where will you go?");
                    }
                }
                else if (roomno == 2)
                {
                    roomno = 4;
                    health -= 1;
                    hape.Text = Convert.ToString(health);
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rLeugrottál a szakadékba. A szakadék alján volt egy tó, amelyben pirányák voltak és megcincáltak. A tóból kimászva látsz egy zölden világító ösvényt és egy börtön kinézetű építményhez vezető részt. Merre mész?");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rYou jump down the chasm. At the bottom of the chasm was a small pond, full of piranhas. You are bitten badly by them. Leaving the pond, you see a glowing path with a distinct, green light, and a section which leads to a building that looks like a prison complex. Where will you go?");
                    }
                }
                else if (roomno == 3)
                {
                    roomno = 7;
                    if (LocalizationNo == 1)
                    {
                        item.Text = "Lámpa";
                    }
                    else if (LocalizationNo == 2)
                    {
                        item.Text = "Flashlight";
                    }
                    itemname = 1;
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rElmentél a bolthoz, és találtál egy zseblámpát. Megpihentél. Ha megpihentél, nyomd meg az egyes gombot, hogy lemerészkedj a sötét barlangba.");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rYou travelled to the shop and found a flashlight. You took a rest. When you are done resting, press button 1 to go down the dark part of the cave.");
                    }
                }
                else if (roomno == 4)
                {
                    roomno = 8;
                    health += 1;
                    hape.Text = Convert.ToString(health);
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rA zölden világító járat mélyén találtál egy öreg kedves boszorkányt. Látta, hogy segítségre van szükséged. Egy gyógyító főzetet adott, ami meggyógyította a sebeidet. Erről már csak a börtön felé mehetsz.");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rGoing down the green glowing path, you found a friendly witch. She noticed that you need help, so she gave you a healing potion, which healed your wounds. You can only travel to the prison from here.");
                    }
                }
                else if (roomno == 5)
                {
                    roomno = 10;
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rAz elhagyatott barlangrészletból elsétálva elérkeztél egy aranyozott téglából épített földalatti kastélyhoz. Itt a bejáratot három nagy, pajzsos, kardos csontváz védte. ");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rWalking away from the abandoned parts of the cave you came across an underground castle built out of gilded bricks. The entrace was guided by three shielded swordsman skeleton. ");
                    }
                    if (itemname == 2)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("A te kardod erejéhez képest ők semmik voltak. Beléphetsz. Egyből mennél a kincsért, vagy alaposan szétnéznél?");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("They couldn't match the power of your sword. You can enter. Would you go straight to claim your treasure, or would you look around first?");
                        }
                    }
                    else
                    {
                        if (health > 1)
                        {
                            health -= 2;
                            hape.Text = Convert.ToString(health);
                        }
                        else if (health == 1)
                        {
                            health -= 1;
                            hape.Text = Convert.ToString(health);
                        }
                        hape.Text = Convert.ToString(health);
                        if (health > 0)
                        {
                            if (LocalizationNo == 1)
                            {
                                richstorybox.AppendText("Egy fájdalmas harc után sebesen, vérezve haladhattál tovább. Beléphetsz. Egyből mennél a kincsért, vagy alaposan szétnéznél?");
                            }
                            else if (LocalizationNo == 2)
                            {
                                richstorybox.AppendText("After a painful fight, you moved on, hurt, bleeding. You can enter. Would you go straight to claim your treasure, or would you look around first?");
                            }
                        }
                        else if (health == 0)
                        {
                            if (LocalizationNo == 1)
                            {
                                richstorybox.AppendText("A csontvázak ereje túllépte a te fizikai képességeidet, és elvéreztél a csatában. A barlang titkait nem ismerted meg.");
                            }
                            else if (LocalizationNo == 2)
                            {
                                richstorybox.AppendText("The skeletons' strength overwhelmed you, and you fell in the battle. You didn't discover the cave's secrets.");
                            }
                        }
                    }
                }
                else if (roomno == 6)
                {
                    roomno = 7;
                    if (LocalizationNo == 1)
                    {
                        item.Text = "Lámpa";
                    }
                    else if (LocalizationNo == 2)
                    {
                        item.Text = "Flashlight";
                    }
                    itemname = 1;
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rElmentél a bolthoz, és találtál egy zseblámpát. Megpihentél. Ha megpihentél, úgy döntöttél, hogy lemerészkedsz a sötét barlangba.");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rYou travelled to the shop and found a flashlight. You took a rest. You decided that you will go down the dark part of the cave when you are done resting.");
                    }
                }
                else if (roomno == 7)
                {
                    roomno = 5;
                    if (itemname == 1)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("\rLesétáltál a sötét barlangrészbe. A zseblámpát használva láttad, hogy tele van a szoba csapdákkal, majd egy nagyon keskeny híd alatt volt egy gödör tele tüskékkel. A hídon óvatosan átsétáltál. Erről csak egy elhagyatott barlangrészlet felé mehetsz.");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("\rYou walk down the dark path. Using the flashlight you saw that the room is filled with traps. The room had a very narrow bridge leading over a pit of spikes. You carefully walk over the bridge. You can only go towards an abandoned part of the cave from here.");
                        }
                    }
                    else if (itemname == 2)
                    {
                        health -= 1;
                        hape.Text = Convert.ToString(health);
                        if (health > 0)
                        {
                            if (LocalizationNo == 1)
                            {
                                richstorybox.AppendText("\rLesétáltál a sötét barlangrészbe. A kardod kék fénye enyhén megvilágította a barlangot. Nem sokat láttál, emiatt belementél egy csapdába és megsebesültél. Ezután viszont láttad, hogy egy nagyon keskeny híd alatt volt egy gödör tele tüskékkel. A hídon óvatosan átsétáltál. Erről csak egy elhagyatott barlangrészlet felé mehetsz.");
                            }
                            else if (LocalizationNo == 2)
                            {
                                richstorybox.AppendText("\rYou walk down the dark path. The faint blue blaze of your sword slightly illuminated the cave. You couldn't make out much from your surroundings, so you fell into a trap and got hurt. After that, you noticed a pit in the room, that was filled with spikes. A narrow bridge goes across the pit. You carefully walk over it. You can only go towards an abandoned part of the cave from here.");
                            }
                        }
                        else if (health == 0)
                        {
                            if (LocalizationNo == 1)
                            {
                                richstorybox.AppendText("\rLesétáltál a sötét barlangrészbe. A kardod kék fénye enyhén megvilágította a barlangot. Nem sokat láttál, emiatt belementél egy csapdába és megsebesültél. A barlang felfedezése közben szerzett sebeid súlyát nem voltál képes kibírni, a csapda helyszínén elhunytál. A barlang titkait nem ismerted meg.");
                            }
                            else if (LocalizationNo == 2)
                            {
                                richstorybox.AppendText("\rYou walk down the dark path. The faint blue blaze of your sword slightly illuminated the cave. You couldn't make out much from your surroundings, so you fell into a trap and got hurt. The injuries you suffered while exploring the cave were too much to handle, so you died near the trap. You didn't discover the cave's secrets.");
                            }
                        }
                    }
                    else
                    {
                        health = 0;
                        hape.Text = Convert.ToString(health);
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("\rLesétáltál a sötét barlangrészbe. Egy pukkanás után egy nyílvessző landolt a térdedbe, és elestél. Lezuhantál egy tüskékkel teli szakadékba. A barlang titkait nem ismerted meg.");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("\rYou walk down the dark path. Following a distinct pop, an arrow hit your knee, and you falled over. You fell down a pit full of spikes. You didn't discover the cave's secrets.");
                        }
                    }
                }
                else if (roomno == 8)
                {
                    roomno = 9;
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rA börtön felé elsétálva láttad, hogy csak egy irányba mehetsz. A börtön egyik ketrecében volt egy bezárt csontváz és mellette nem messze egy kéken világító, szinte már lángoló kard. Mit teszel? Mész tovább vagy megpróbálod megszerezni a kardot?");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rWalking towards the prison you realised that you can only go in one direction. In one of the cells was a skeleton and not far from him, a sword, glowing with a blue light, almost blazing. What will you do? Will you go on or will you try to obtain the sword?");
                    }
                }
                else if (roomno == 9)
                {
                    roomno = 11;
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rÁtértél a börtön másik oldalára. Látsz egy aranyozott építményt az egyik ösvény végén és egy nagyon meredek lejtőt, amely sötétségben végződik a másik ösvény végén. Merre mész?");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rYou pass through to the other side of the prison. You see a gilded building at the end of a path and a very steep incline that ends in darkness in the other path. Where will you go?");
                    }
                }
                else if (roomno == 10)
                {
                    roomno = 13;
                    if (LocalizationNo == 1)
                    {
                        item.Text = "Kincs";
                    }
                    else if (LocalizationNo == 2)
                    {
                        item.Text = "Treasure";
                    }
                    itemname = 4;
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rBeléptél a kastélyba. Elindultál a kincstároló részleghez. A kastély kincseit saját magadnak tudhatod. Sok kincset és gyönyörködést magaddal ragadva a kastély vége felé vetted az irányt. A kastély végén egy egyirányú csúszda végén egy csapóajtó kiengedett a hegy másik oldalán, egy szép tó mellé. ");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rYou enter the castle. You head towards the treasure chambers. You now own the treasure of the castle. Grabbing lots of treasure and admiration, you head towards the end of the castle. Reaching your destination, you leave the castle via a trapdoor leading to a slide that led to the other side of the mountain, next to a beautiful pond. ");
                    }
                    if (voltkardod == 1)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("Megcsodálod még egyszer a szép kardodat. ");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("You admire your wonderful sword once again.");
                        }
                    }
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("Elhagytad a barlang területét.");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("You left the area of the cave.");
                    }
                }
                else if (roomno == 11)
                {
                    roomno = 10;
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rAz első ösvényen végigsétálva elérkeztél egy aranyozott téglából épített földalatti kastélyhoz. Itt a bejáratot három nagy, pajzsos, kardos csontváz védte. ");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rWalking down the first path you came across an underground castle built out of gilded bricks. The entrace was guided by three shielded swordsman skeleton. ");
                    }
                    if (itemname == 2)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("A te kardod erejéhez képest ők semmik voltak. Beléphetsz. Egyből mennél a kincsért, vagy alaposan szétnéznél?");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("They couldn't match the power of your sword. You can enter. Would you go straight to claim your treasure, or would you look around first?");
                        }
                    }
                    else
                    {
                        if (health > 1)
                        {
                            health -= 2;
                            hape.Text = Convert.ToString(health);
                        }
                        else if (health == 1)
                        {
                            health -= 1;
                            hape.Text = Convert.ToString(health);
                        }
                        hape.Text = Convert.ToString(health);
                        if (health > 0)
                        {
                            if (LocalizationNo == 1)
                            {
                                richstorybox.AppendText("Egy fájdalmas harc után sebesen, vérezve haladhattál tovább. Beléphetsz. Egyből mennél a kincsért, vagy alaposan szétnéznél?");
                            }
                            else if (LocalizationNo == 2)
                            {
                                richstorybox.AppendText("After a painful fight, you moved on, hurt, bleeding. Would you go straight to claim your treasure, or would you look around first?");
                            }
                        }
                        else if (health == 0)
                        {
                            if (LocalizationNo == 1)
                            {
                                richstorybox.AppendText("A csontvázak ereje túllépte a te fizikai képességeidet, és elvéreztél a csatában. A barlang titkait nem ismerted meg.");
                            }
                            else if (LocalizationNo == 2)
                            {
                                richstorybox.AppendText("The skeletons' strength overwhelmed you, and you fell in the battle. You didn't discover the cave's secrets.");
                            }
                        }
                    }
                }
                else if (roomno == 12)
                {
                    roomno = 7;
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rA kocsmában szétnézve láttad, hogy a mosdók melletti fapadló furán néz ki. Felemelted a csapóajtót, és az ott lévő létrán lemásztál. A létra alja három és fél méterrel a föld fölött volt. Leereszkettél a legalsó fokra, a lehető legalacsonyabbra lelógattad magad a kezednél fogva, majd leugrottál, és egy boltban landoltál. ");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rLooking around in the pub, you noticed some suspicious-looking wooden tiles near the bathrooms. You lifted the trapdoor tile and you descended on the ladder that was there. The bottom of the ladder was three and a half meters above the ground. You grab the lowest part of the ladder and slowly lower your body. You drop down into a shop. ");
                    }
                    if (itemname == 3)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("A sörödet elejtetted, a csillogós kristálykorsó leesett a földre és milliónyi apró darabra tört. A sör szétfolyt a padlón, mint a folyékony arany. Mekkora pazarlás. ");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("You drop your beer from the fall. The glistering cristal jug dropped to the ground and broke into a million small pieces. The beer flows apart on the floor like molten gold. What a waste. ");
                        }
                    }
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("A boltban találtál egy zseblámpát. Ha indulni akarsz, indulj el az egyetlen kivezető ösvényen, és merészkedj le a sötét barlangba.");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("In the shop you found a flashlight. If you want to leave, go on the only path that leads away from here and go down into the dark part of the cave.");
                    }
                    if (LocalizationNo == 1)
                    {
                        item.Text = "Lámpa";
                    }
                    else if (LocalizationNo == 2)
                    {
                        item.Text = "Flashlight";
                    }
                    itemname = 1;
                }
                else if (roomno == 13)
                {
                    win = 1;
                    if (LocalizationNo == 1)
                    {
                        MessageBox.Show("Gratulálunk, megtaláltad a kincset. Szép játék volt!", "Barlang Kaland értesítés");
                    }
                    else if (LocalizationNo == 2)
                    {
                        MessageBox.Show("Congratulations, you found the treasure. Good game!", "Cave Adventure notification");
                    }
                }
                else if (roomno == 14)
                {
                    roomno = 13;
                    if (LocalizationNo == 1)
                    {
                        item.Text = "Kincs";
                    }
                    else if (LocalizationNo == 2)
                    {
                        item.Text = "Treasure";
                    }
                    itemname = 4;
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rElindultál a hálószobából, elmentél a kincstároló részleghez. A kastély kincseit saját magadnak tudhatod. Sok kincset és gyönyörködést magaddal ragadva a kastély vége felé vetted az irányt. Még egyszer megnézted a szett gyönyörűséges páncélt, ");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rMoving from the bedrooms, you went to the treasure chambers. You now own the treasure of the castle. Grabbing lots of treasure and admiration, you head towards the end of the castle. You take a look once again at your beautiful set of armor, ");
                    }
                    if (voltkardod == 0)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("amely mély kéken világított. Soha nem láttál még ilyet. ");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("which shone with a deep blue color. You have never seen something like that before. ");
                        }
                    }
                    else if (voltkardod == 1)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("amely ugyanazzal a szép, mély kék fénnyel világított, mint ahogyan a kardod világít. ");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("which shone with the same beautiful, deep blue color that your sword does. ");
                        }
                    }
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("A kastély végén egy egyirányú csúszda végén egy csapóajtó kiengedett a hegy másik oldalán, egy szép tó mellé. ");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("Reaching your destination, you leave the castle via a slide leading to a trapdoor that let you out on the other side of the mountain, next to a beautiful pond. ");
                    }
                    if (voltkardod == 1)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("Megcsodálod még egyszer a szép kardodat. ");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("You admire your amazing sword once more. ");
                        }
                    }
                    if (voltpancelod == 1)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("Utoljára ránézel a páncélodra. Képtelen vagy elhinni, milyen gyönyörű. ");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("You take a look at your armor once more for now. You still cannot believe how beautiful it is. ");
                        }
                    }
                    if (voltpancelod == 1 && voltkardod == 1)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("A kardot ráteszed a páncélod vállára, ami meg is tartja. Ahol a két különleges tárgy összeér, pirossá válik a fény. Kifejezetten csodálatos. ");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("You put the sword on the shoulderpiece of your armor, which sustains it. The part where the two special items touch, they glow red. Especially enchanting. ");
                        }
                    }
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("Elhagytad a barlang területét.");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("You left the area of the cave.");
                    }
                }
            }
            else if (win == 1)
            {
                if (LocalizationNo == 1)
                {
                    MessageBox.Show("Már nem kell tenned semmit. Élvezd a megérdemelt kincseidet.", "Barlang Kaland értesítés");
                }
                else if (LocalizationNo == 2)
                {
                    MessageBox.Show("You don't have to do anything now. Enjoy your treausre, you earned it.", "Cave Adventure notification");
                }

            }
            else
            {
                death = 1;
                if (LocalizationNo == 1)
                {
                    MessageBox.Show("Sajnálom, vesztettél. Indítsd újra a játékot, ha újra akarod próbálni.", "Barlang Kaland értesítés");
                }
                else if (LocalizationNo == 2)
                {
                    MessageBox.Show("You lost. Restart the game if you want to try again.", "Cave Adventure notification");
                }
            }
        }

        private void option2_Click(object sender, RoutedEventArgs e)
        {
            if (health != 0 && win != 1)
            {
                if (roomno == 1)
                {
                    roomno = 12;
                    if (LocalizationNo == 1)
                    {
                        item.Text = "Sör";
                    }
                    else if (LocalizationNo == 2)
                    {
                        item.Text = "Beer";
                    }
                    itemname = 3;
                    health -= 1;
                    hape.Text = Convert.ToString(health);
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rA kocsma felé indultál el. (Iszákos...) A kocsmában a csapostól kértél egy korsó sört, aki oda is adta. Miközben a barlangról beszélgettél a csapossal, két óriási pók jött ki a fa deszkák alól. A csapos elájult, ezt kihasználva az egyik pók élve megette. Te az egyik pókot megölted, míg a másik evett. A másik pók miután megette a csapost, mérget lőtt rád, ami megmarta a bal kezed bőrét. A másik pókot is megölted, de megsebesültél. Jó ötlet lenne meginni a sört.");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rYou head over to the pub. (Drunkard...) You ask the bartender for a jug of beer, and he delivers. While you were talking about the cave with the bartender, two gigantic spiders came out from under the wooden tiles. He fainted. Taking advantage of this, one of the spiders devoured him alive. While that spider was busy eating, you killed the other spider. Having consumed the poor guy, the spider shot poision onto your left hand's skin. Being hurt, you finish off the spider. It would be a great idea to drink that beer.");
                    }
                }
                else if (roomno == 2)
                {
                    roomno = 5;
                    if (itemname == 1)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("\rLesétáltál a sötét barlangrészbe. A zseblámpát használva láttad, hogy tele van a szoba csapdákkal, majd egy nagyon keskeny híd alatt volt egy gödör tele tüskékkel. A hídon óvatosan átsétáltál. Erről csak egy elhagyatott barlangrészlet felé mehetsz.");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("\rYou walk down the dark path. Using the flashlight you saw that the room is filled with traps. The room had a very narrow bridge leading over a pit of spikes. You carefully walk over the bridge. You can only go towards an abandoned part of the cave from here.");
                        }
                    }
                    else if (itemname == 2)
                    {
                        health -= 1;
                        hape.Text = Convert.ToString(health);
                        if (health > 0)
                        {
                            if (LocalizationNo == 1)
                            {
                                richstorybox.AppendText("\rLesétáltál a sötét barlangrészbe. A kardod kék fénye enyhén megvilágította a barlangot. Nem sokat láttál, emiatt belementél egy csapdába és megsebesültél. Ezután viszont láttad, hogy egy nagyon keskeny híd alatt volt egy gödör tele tüskékkel. A hídon óvatosan átsétáltál. Erről csak egy elhagyatott barlangrészlet felé mehetsz.");
                            }
                            else if (LocalizationNo == 2)
                            {
                                richstorybox.AppendText("\rYou walk down the dark path. The faint blue blaze of your sword slightly illuminated the cave. You couldn't make out much from your surroundings, so you fell into a trap and got hurt. After that, you noticed a pit in the room, that was filled with spikes. A narrow bridge goes across the pit. You carefully walk over it. You can only go towards an abandoned part of the cave from here.");
                            }
                        }
                        else if (health == 0)
                        {
                            if (LocalizationNo == 1)
                            {
                                richstorybox.AppendText("\rLesétáltál a sötét barlangrészbe. A kardod kék fénye enyhén megvilágította a barlangot. Nem sokat láttál, emiatt belementél egy csapdába és megsebesültél. A barlang felfedezése közben szerzett sebeid súlyát nem voltál képes kibírni, a csapda helyszínén elhunytál. A barlang titkait nem ismerted meg.");
                            }
                            else if (LocalizationNo == 2)
                            {
                                richstorybox.AppendText("\rYou walk down the dark path. The faint blue blaze of your sword slightly illuminated the cave. You couldn't make out much from your surroundings, so you fell into a trap and got hurt. The injuries you suffered while exploring the cave were too much to handle, so you died near the trap. You didn't discover the cave's secrets.");
                            }
                        }
                    }
                    else
                    {
                        health = 0;
                        hape.Text = Convert.ToString(health);
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("\rLesétáltál a sötét barlangrészbe. Egy pukkanás után egy nyílvessző landolt a térdedbe, és elestél. Lezuhantál egy tüskékkel teli szakadékba. A barlang titkait nem ismerted meg.");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("\rYou walk down the dark path. Following a distinct pop, an arrow hit your knee, and you falled over. You fell down a pit full of spikes. You didn't discover the cave's secrets.");
                        }
                    }
                }
                else if (roomno == 4)
                {
                    roomno = 9;
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rVeszélyesnek nézett ki a világító rész, emiatt elsétáltál a börtön felé. A börtön egyik ketrecében volt egy bezárt csontváz és mellette nem messze egy kéken világító, szinte már lángoló kard. Mit teszel? Mész tovább vagy megpróbálod megszerezni a kardot?");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rThe glowing path looked intimidating, so you walked towards the prison instead. In one of the cells was a skeleton and not far from him, a sword, glowing with a blue light, almost blazing. What will you do? Will you go on or will you try to obtain the sword?");
                    }
                }
                else if (roomno == 6)
                {
                    roomno = 5;
                    if (itemname == 1)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("\rLesétáltál a sötét barlangrészbe. A zseblámpát használva láttad, hogy tele van a szoba csapdákkal, majd egy nagyon keskeny híd alatt volt egy gödör tele tüskékkel. A hídon óvatosan átsétáltál. Erről csak egy elhagyatott barlangrészlet felé mehetsz.");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("\rYou walk down the dark path. Using the flashlight you saw that the room is filled with traps. The room had a very narrow bridge leading over a pit of spikes. You carefully walk over the bridge. You can only go towards an abandoned part of the cave from here.");
                        }
                    }
                    else if (itemname == 2)
                    {
                        health -= 1;
                        hape.Text = Convert.ToString(health);
                        if (health > 0)
                        {
                            if (LocalizationNo == 1)
                            {
                                richstorybox.AppendText("\rLesétáltál a sötét barlangrészbe. A kardod kék fénye enyhén megvilágította a barlangot. Nem sokat láttál, emiatt belementél egy csapdába és megsebesültél. Ezután viszont láttad, hogy egy nagyon keskeny híd alatt volt egy gödör tele tüskékkel. A hídon óvatosan átsétáltál. Erről csak egy elhagyatott barlangrészlet felé mehetsz.");
                            }
                            else if (LocalizationNo == 2)
                            {
                                richstorybox.AppendText("\rYou walk down the dark path. The faint blue blaze of your sword slightly illuminated the cave. You couldn't make out much from your surroundings, so you fell into a trap and got hurt. After that, you noticed a pit in the room, that was filled with spikes. A narrow bridge goes across the pit. You carefully walk over it. You can only go towards an abandoned part of the cave from here.");
                            }
                        }
                        else if (health == 0)
                        {
                            if (LocalizationNo == 1)
                            {
                                richstorybox.AppendText("\rLesétáltál a sötét barlangrészbe. A kardod kék fénye enyhén megvilágította a barlangot. Nem sokat láttál, emiatt belementél egy csapdába és megsebesültél. A barlang felfedezése közben szerzett sebeid súlyát nem voltál képes kibírni, a csapda helyszínén elhunytál. A barlang titkait nem ismerted meg.");
                            }
                            else if (LocalizationNo == 2)
                            {
                                richstorybox.AppendText("\rYou walk down the dark path. The faint blue blaze of your sword slightly illuminated the cave. You couldn't make out much from your surroundings, so you fell into a trap and got hurt. The injuries you suffered while exploring the cave were too much to handle, so you died near the trap. You didn't discover the cave's secrets.");
                            }
                        }
                    }
                    else
                    {
                        health = 0;
                        hape.Text = Convert.ToString(health);
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("\rLesétáltál a sötét barlangrészbe. Egy pukkanás után egy nyílvessző landolt a térdedbe, és elestél. Lezuhantál egy tüskékkel teli szakadékba. A barlang titkait nem ismerted meg.");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("\rYou walk down the dark path. Following a distinct pop, an arrow hit your knee, and you falled over. You fell down a pit full of spikes. You didn't discover the cave's secrets.");
                        }
                    }
                }
                else if (roomno == 9 && csonti == 0)
                {
                    health -= 1;
                    hape.Text = Convert.ToString(health);
                    if (LocalizationNo == 1)
                    {
                        item.Text = "Kard";
                    }
                    else if (LocalizationNo == 2)
                    {
                        item.Text = "Sword";
                    }
                    itemname = 2;
                    voltkardod = 1;
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rOdasétálsz a csontváz ketrecéhez. Megpróbálsz benyúlni a kardért, de a csontváz felugrik és gyorsan ráver a könyököd hátuljára. Te a fájdalomtól hirtelen visszahúzod a kezed, addig pedig a csontváz felveszi a kardot. Ott áll előtted egy dühös tekintettel a félelmetes kardot tartó csontváz. Te gyorsan gondolkodsz és a másik kezed öklével telibe az arcába ütsz. A feje leesik a helyéről, majd a földön landol, és egy kifejezetten vicceset pukkan. A csontváz összeesik, a kard pedig leesik a földre. Amikor leesik, óriási, fémes visszhangot áraszt a barlangban. Szerencsére pont úgy esik le, hogy kicsúszik a ketrecből. Megcsodálod a gyönyörű (és különleges!) kardot, majd felveszed. Elindultál a börtön vége felé.");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rYou walk to the cage of the skeleton. You reach out for the sword, but the skeleton hops up and quickly hits the back of your elbow. You quickly pull your hand out from the pain, and while you're doing that, the skeleton grabs the sword. The skeleton is standing in front of you with an angry look, holding the fearsome sword. Doing some quick thinking, you swiftly hit the skeleton straight in the middle of the head with your fist. The head falls out of its' place, then hits groud with an especially funny pop sound. The skeleton falls over and the sword falls to the ground. When it touches the ground, it gives out an enormous metallic echo that permeates the cave. Luckily, it falls down in a way that it tumbles out of the cage. You admire the beautiful (and special!) sword, then you pick it up. You depart to the end of the prison.");
                    }
                    csonti = 1;
                }
                else if (roomno == 10)
                {
                    roomno = 14;
                    if (LocalizationNo == 1)
                    {
                        item.Text = "Páncél";
                    }
                    else if (LocalizationNo == 2)
                    {
                        item.Text = "Armor";
                    }
                    itemname = 5;
                    voltpancelod = 1;
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rAlaposan körülnéztél a kastélyban. Az egyik hálószobában találtál egy páncélállványon egy kéken világító titánszürke páncélt, amit fel is vettél. Miután szétnéztél, úgy döntöttél, hogy elindulsz.");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rYou thoroughly look around in the castle. In one of the bedrooms you found a titanium gray set of armor that let out a blue light. You equip the armor. After having looked around, you decide to get going.");
                    }
                }
                else if (roomno == 11)
                {
                    roomno = 5;
                    if (itemname == 1)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("\rLecsúsztál a lejtőn. A zseblámpát használva láttad, hogy tele van a sötét szoba csapdákkal, majd egy nagyon keskeny híd alatt volt egy gödör tele tüskékkel. A hídon óvatosan átsétáltál. Erről csak egy elhagyatott barlangrészlet felé mehetsz.");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("\rYou slide down the incline. Using the flashlight you saw that the room is filled with traps. The room had a very narrow bridge leading over a pit of spikes. You carefully walk over the bridge. You can only go towards an abandoned part of the cave from here.");
                        }
                    }
                    else if (itemname == 2)
                    {
                        health -= 1;
                        hape.Text = Convert.ToString(health);
                        if (health > 0)
                        {
                            if (LocalizationNo == 1)
                            {
                                richstorybox.AppendText("\rLecsúsztál a lejtőn. A kardod kék fénye enyhén megvilágította a barlangot. Nem sokat láttál, emiatt belementél egy csapdába és megsebesültél. Ezután viszont láttad, hogy egy nagyon keskeny híd alatt volt egy gödör tele tüskékkel. A hídon óvatosan átsétáltál. Erről csak egy elhagyatott barlangrészlet felé mehetsz.");
                            }
                            else if (LocalizationNo == 2)
                            {
                                richstorybox.AppendText("\rYou slide down the incline. The faint blue blaze of your sword slightly illuminated the cave. You couldn't make out much from your surroundings, so you fell into a trap and got hurt. After that, you noticed a pit in the room, that was filled with spikes. A narrow bridge goes across the pit. You carefully walk over it. You can only go towards an abandoned part of the cave from here.");
                            }
                        }
                        else if (health == 0)
                        {
                            if (LocalizationNo == 1)
                            {
                                richstorybox.AppendText("\rLecsúsztál a lejtőn. A kardod kék fénye enyhén megvilágította a barlangot. Nem sokat láttál, emiatt belementél egy csapdába és megsebesültél. A barlang felfedezése közben szerzett sebeid súlyát nem voltál képes kibírni, a csapda helyszínén elhunytál. A barlang titkait nem ismerted meg.");
                            }
                            else if (LocalizationNo == 2)
                            {
                                richstorybox.AppendText("\rYou slide down the incline. The faint blue blaze of your sword slightly illuminated the cave. You couldn't make out much from your surroundings, so you fell into a trap and got hurt. The injuries you suffered while exploring the cave were too much to handle, so you died near the trap. You didn't discover the cave's secrets.");
                            }
                        }
                    }
                    else
                    {
                        health = 0;
                        hape.Text = Convert.ToString(health);
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("\rLecsúsztál a lejtőn. A lejtő alján nem láttál semmit, óvtosan elkezdtél sétálni. Az egyik lépésnél óriásit kattant valami, majd leomlott alattad a föld. Leestél egy tüskékkel teli szakadékba. A barlang titkait nem ismerted meg.");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("\rYou slide down the incline. You couldn't make out anything in the bottom of darkness, so you started slowly walking. After one of the steps you heard a loud click and the earth falled out from below you. You fell into a pit of spikes. You didn't discover the cave's secrets.");
                        }
                    }
                }
            }
            else if (win == 1)
            {
                if (LocalizationNo == 1)
                {
                    MessageBox.Show("Már nem kell tenned semmit. Élvezd a megérdemelt kincseidet.", "Barlang Kaland értesítés");
                }
                else if (LocalizationNo == 2)
                {
                    MessageBox.Show("You don't have to do anything now. Enjoy your treausre, you earned it.", "Cave Adventure notification");
                }

            }
            else
            {
                death = 1;
                if (LocalizationNo == 1)
                {
                    MessageBox.Show("Sajnálom, vesztettél. Indítsd újra a játékot, ha újra akarod próbálni.", "Barlang Kaland értesítés");
                }
                else if (LocalizationNo == 2)
                {
                    MessageBox.Show("You lost. Restart the game if you want to try again.", "Cave Adventure notification");
                }
            }
        }

        private void option3_Click(object sender, RoutedEventArgs e)
        {
            if (health != 0 && win != 1)
            {
                if (roomno == 1)
                {
                    roomno = 4;
                    health -= 1;
                    hape.Text = Convert.ToString(health);
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rElmentél a vízesés felé. \"Na, akkor ugorjunk\" - és leugrottál. Hideg volt a víz, fura érzés volt. A gyors esésű vízesés alján egy tóban landoltál. A tóban pirányák voltak és megcincáltak. A tóból kimászva látsz egy zölden világító ösvényt és egy börtön kinézetű építményhez vezető részt. Merre mész?");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rYou go to the waterfall. \"Let's jump\" - so you did. The water was cold and made you feel tingly. The waterfall was very fast. At the bottom you land in a pond full of pirahnas. You are bitten badly by them. Leaving the pond, you see a glowing path with a distinct, green light, and a section which leads to a building that looks like a prison complex. Where will you go?");
                    }
                }
                else if (roomno == 2)
                {
                    roomno = 6;
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rVégigsétáltál a járaton. Három ösvényt látsz: az egyik egy bolt felé vezet, a másik egy sötét barlangrész felé, a harmadik pedig egy ciripeléshangokkal teli részhez vezet. Merre mész?");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rYou walk down the passage. You see three paths: one leads to a shop, one to a dark part of the cave and one to a part that's full of chirring sounds. Where will you go?");
                    }
                }
                else if (roomno == 6)
                {
                    roomno = 3;
                    health -= 1;
                    hape.Text = Convert.ToString(health);
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rElsétáltál a ciripelős részre. Hirtelen csend lett. Álltál, egy helyben. Hirtelen hangos lett és denevérek leptek el. Megmart sok denevér, majd  elmentek. Megsérültél. Erről egyfelé lehetett menni, a bolt egy titkos bejáratához.");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rYou walk towards the chirring sounds. Suddenly, silence. You stand in place, intimidated. All of a sudden loud noises fill the room and bats fly in. Lots of them bite you, then they leave. You can go one way from here: to a secret entrace of the shop.");
                    }
                }
            }
            else if (win == 1)
            {
                if (LocalizationNo == 1)
                {
                    MessageBox.Show("Már nem kell tenned semmit. Élvezd a megérdemelt kincseidet.", "Barlang Kaland értesítés");
                }
                else if (LocalizationNo == 2)
                {
                    MessageBox.Show("You don't have to do anything now. Enjoy your treausre, you earned it.", "Cave Adventure notification");
                }

            }
            else
            {
                death = 1;
                if (LocalizationNo == 1)
                {
                    MessageBox.Show("Sajnálom, vesztettél. Indítsd újra a játékot, ha újra akarod próbálni.", "Barlang Kaland értesítés");
                }
                else if (LocalizationNo == 2)
                {
                    MessageBox.Show("You lost. Restart the game if you want to try again.", "Cave Adventure notification");
                }
            }
        }

        private void useitem_Click(object sender, RoutedEventArgs e)
        {
            if (win != 1)
            {
                if (itemname == 0)
                {
                    if (uresnezes != 1 && health > 0)
                    {
                        uresnezes = 1;
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("\rMost épp nincs nálad semmi. Jó, van nálad egy csomag zsebkendő. Kifújtad az orrodat.");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("\rYou currently have no items. Okay you have a packet of tissues. You blow your nose.");
                        }
                    }
                    else if (death == 1)
                    {
                        if (LocalizationNo == 1)
                        {
                            MessageBox.Show("Sajnálom, vesztettél. Indítsd újra a játékot, ha újra akarod próbálni.", "Barlang Kaland értesítés");
                        }
                        else if (LocalizationNo == 2)
                        {
                            MessageBox.Show("You lost. Restart the game if you want to try again.", "Cave Adventure notification");
                        }
                    }
                }
                if (itemname == 1)
                {
                    if (death == 1)
                    {
                        if (LocalizationNo == 1)
                        {
                            MessageBox.Show("Sajnálom, vesztettél. Indítsd újra a játékot, ha újra akarod próbálni.", "Barlang Kaland értesítés");
                        }
                        else if (LocalizationNo == 2)
                        {
                            MessageBox.Show("You lost. Restart the game if you want to try again.", "Cave Adventure notification");
                        }
                    }
                    else if(lampanezes !=1)
                    {
                        lampanezes = 1;
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("\rMegnézted a zseblámpádat. Öreg, nehéz lámpa, de nagyon erős fényű és széles területet világít meg.");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("\rYou inspect your flashlight. It is old and heavy, but it's remarkably bright and illuminates a very wide area.");
                        }
                    }
                }
                if (itemname == 2)
                {
                    if (death == 1)
                    {
                        if (LocalizationNo == 1)
                        {
                            MessageBox.Show("Sajnálom, vesztettél. Indítsd újra a játékot, ha újra akarod próbálni.", "Barlang Kaland értesítés");
                        }
                        else if (LocalizationNo == 2)
                        {
                            MessageBox.Show("You lost. Restart the game if you want to try again.", "Cave Adventure notification");
                        }
                    }
                    else if(kardnezes != 1)
                    {
                        kardnezes = 1;
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("\rMegnézted a kardot. Óriási, nehéz kard. Hideg a tapintásra, de a kék fénye égető fájdalmat sugároz a kezedre, mikor közel tartottad. Rettenetesen élesnek néz ki. Inkább úgy döntesz, hogy csak a fogantyújánál fogod innentől.");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("\rYou look at your sword. It is an enormous, heavy sword. It's cold to the touch, but its' blue glow radiated painful heat to your hand when you held it close. It looks incredibly sharp. You decide to only grab the handle from now on.");
                        }
                    }
                }
                if (itemname == 3)
                {
                    if (roomno != 5)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("\rMegittad a sört. Nagyon hideg, jó komlós íze van. Nagyon jó érzés.");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("\rYou drink the beer. It's cold and has a really good hops flavor. It feels really good to drink.");
                        }
                        health += 2;
                        hape.Text = Convert.ToString(health);
                        if (LocalizationNo == 1)
                        {
                            item.Text = "Üres";
                        }
                        else if (LocalizationNo == 2)
                        {
                            item.Text = "Empty";
                        }
                        itemname = 0;
                    }
                    else
                    {
                        if (LocalizationNo == 1)
                        {
                            MessageBox.Show("Sajnálom, vesztettél. Indítsd újra a játékot, ha újra akarod próbálni.", "Barlang Kaland értesítés");
                        }
                        else if (LocalizationNo == 2)
                        {
                            MessageBox.Show("You lost. Restart the game if you want to try again.", "Cave Adventure notification");
                        }
                    }
                }
                if (itemname == 4 && kincsnezes == 0)
                {
                    kincsnezes = 1;
                    if (voltkardod == 1 && voltpancelod == 0)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("\rMegnézed a kincseidet. Egy kisebb ládányi aranyat és ékszert vittél el magaddal a kardodon kívül. Mindegyik gyönyörű szép, és valószínűleg értékes.");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("\rYou look at your treasure. You brought a small chest of gold and jewellery with you, aside from your sword. They all look beautifully good, and are probably really valuable.");
                        }
                    }
                    if (voltpancelod == 1 && voltkardod == 0)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("\rMegnézed a kincseidet. Egy kisebb ládányi aranyat és ékszert vittél el magaddal a páncélon kívül. Mindegyik gyönyörű szép, és valószínűleg értékes.");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("\rYou look at your treasure. You brought a small chest of gold and jewellery with you, aside from your armor. They all look beautifully good, and are probably really valuable.");
                        }
                    }
                    if (voltkardod == 1 && voltpancelod == 1)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("\rMegnézed a kincseidet. Egy kisebb ládányi aranyat és ékszert vittél el magaddal a páncélon és a kardon kívül. Mindegyik gyönyörű szép, és valószínűleg értékes.");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("\rYou look at your treasure. You brought a small chest of gold and jewellery with you, aside from your armor and sword. They all look beautifully good, and are probably really valuable.");
                        }
                    }
                    if (voltkardod == 0 && voltpancelod == 0)
                    {
                        if (LocalizationNo == 1)
                        {
                            richstorybox.AppendText("\rMegnézed a kincseidet. Egy kisebb ládányi aranyat és ékszert vittél el magaddal. Mindegyik gyönyörű szép, és valószínűleg értékes.");
                        }
                        else if (LocalizationNo == 2)
                        {
                            richstorybox.AppendText("\rYou look at your treasure. You brought a small chest of gold and jewellery with you. They all look beautifully good, and are probably really valuable.");
                        }
                    }
                }
                if (itemname == 5 && pancelnezes == 0)
                {
                    pancelnezes = 1;
                    if (LocalizationNo == 1)
                    {
                        richstorybox.AppendText("\rMegnézted a páncélt. Meglepően könnyű a kinézetéhez képest. A páncéltól erősnek érzed magad.");
                    }
                    else if (LocalizationNo == 2)
                    {
                        richstorybox.AppendText("\rYou survey your armor. It is suprisingly light despite the look of it. It makes you feel strong.");
                    }
                }
            }
            else
            {
                if (LocalizationNo == 1)
                {
                    MessageBox.Show("Már nem kell tenned semmit. Élvezd a megérdemelt kincseidet.", "Barlang Kaland értesítés");
                }
                else if (LocalizationNo == 2)
                {
                    MessageBox.Show("You don't have to do anything now. Enjoy your treausre, you earned it.", "Cave Adventure notification");
                }
            }
        }
    }
}
